﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormCartela
{
    class Cartela
    {
        public List<Label> Numeros { get; set; }
    }

    public Cartela(int num)
{
    Numeros = new List<Label>();

    for (int i = 0; i < num; i++)
			{
			 
			}
}